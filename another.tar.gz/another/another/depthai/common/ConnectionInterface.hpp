#pragma once
#include <cstdint>

namespace dai {
enum class ConnectionInterface : int32_t { USB, ETHERNET, WIFI };
}  // namespace dai
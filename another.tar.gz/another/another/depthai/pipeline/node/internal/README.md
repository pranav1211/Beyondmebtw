## Internal depthai-core nodes

Nodes used internally in `depthai-core` that are not ment to be used in user-defined programs. API may change.